import tkinter as tk
from tkinter import *
class SampleApp(tk. Tk):


    def __init__(self,*arg,**kwargs):
        tk.Tk.__init__(self,*arg,**kwargs)
        container=tk.Frame(self)
        container.pack(side='top',fill='both',expand=True)
        container.grid_rowconfigure(0,weight=1)
        container.grid_columnconfigure(0,weight=1)

        self.frames={}
        for F in(StartPage, MenuPage, Logo, Courses, Teachers, Schedules, Students, Payments, get_Lesson,get_Pricelist):
            page_name=F.__name__
            frame=F(parent=container,controller=self)
            self.frames[page_name]=frame

            frame.grid(row=0,column=0,sticky='nsew')

            self.show_frame('StartPage')

    def show_frame(self,page_name):
        frame = self.frames[page_name]
        frame.tkraise()

class StartPage(tk.Frame):
    def __init__(self,parent,controller):
        tk.Frame.__init__(self,parent, bg ="white")
        self.backGroundImage = PhotoImage(file=r"C:\Users\User\Desktop\img/students.png")
        self.backGroundImageLabel = Label(self, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=190, y=100)
        self.controller=controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable=tk.Label(self,text='I KNOW ACADEMY', font=('Candara',50,'bold'),fg='black',bg='white')
        big_lable.pack(pady=30)

        login_lable=tk.Label(self,text='Entry login', font=('Candara',15,'bold'),bg='white',fg='black')
        login_lable.pack(pady=30)

        my_login=tk.StringVar()
        login_entry=tk.Entry(self,textvariable=my_login, font=('Candara',15,'bold'),bg='white',fg='black')
        login_entry.pack(pady=30)

        password_lable=tk.Label(self,text='Entry password', font=('Candara',15,'bold'),bg='white',fg='black')
        password_lable.pack(pady=30)

        my_password= tk.StringVar()
        password_entry = tk.Entry(self, textvariable=my_password, font=('Candara', 15, 'bold'), bg='white',fg='black')
        password_entry.pack(pady=30)


        def check_password():
            if my_password.get()=='1' and my_login.get()=='a':
                controller.show_frame('MenuPage')


            else:
                right_lable['text']='Invalid password or login'

        password_button=tk.Button(self,text='Sign in',command=check_password,
                                  font=('Candara',15,'bold'),bg='white',fg='black')
        password_button.pack()
        right_lable=tk.Label(self,font=('Candara',15,'bold'),bg='white',fg='black')
        right_lable.pack(pady=30)








class MenuPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self,parent,bg='red')
        tk.Frame.__init__(self, parent, bg="white")
        self.backGroundImage = PhotoImage(file=r"C:\Users\User\Desktop\img/students.png")
        self.backGroundImageLabel = Label(self, image=self.backGroundImage)
        self.backGroundImageLabel.place(x=190, y=100)
        self.controller=controller
        big_lable = tk.Label(self, text='Welcome in I KNOW ACADEMY', font=('Candara', 50, 'bold'), fg='black', bg='white')
        big_lable.pack(pady=30)
        big_lable.place(x=200, y=40)

        def get_logo():
            controller.show_frame('Logo')

        contact_button = tk.Button(self, text="Study Centres", command=(get_logo), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=500)

        def get_courses():
            controller.show_frame('Courses')

        contact_button = tk.Button(self, text="Courses", command=(get_courses), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=600)

        def get_teachers():
            controller.show_frame('Teachers')

        contact_button = tk.Button(self, text="Teachers", command=(get_teachers), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=400)

        def get_Schedules():
            controller.show_frame('Schedules')

        contact_button = tk.Button(self, text="Schedules", command=(get_Schedules), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=300)

        def get_Students():
            controller.show_frame('Students')

        contact_button = tk.Button(self, text="Students", command=(get_Students), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=200)

        def get_Payments():
            controller.show_frame('Payments')

        contact_button = tk.Button(self, text="parents", command=(get_Payments), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=200, y=200)






class Logo(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='ABOUT I KNOW ACADEMY', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        text = tk.Label(self, text='We are glad that you have chosen our training center \n', font=('Candara', 20, 'bold'), fg='white', bg='red')
        text.pack(pady=30)

        text = tk.Label(self, text='We are redy to provide you with our courses in the form of ENGLISH RUSSIAN and MATH \n',
                        font=('Candara', 20, 'bold'), fg='white', bg='red')
        text.pack(pady=30)

        text = tk.Label(self,
                        text='Applications individually and each student is provided with personal floggins Please do not distribute these floggings \n',
                        font=('Candara', 20, 'bold'), fg='white', bg='red')
        text.pack(pady=30)

        big_lable = tk.Label(self, font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)

        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='white', bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)

class Courses(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="white")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='RUSSIAN', font=('Candara', 50, 'bold'), fg='black', bg='white')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=200)
        big_lable = tk.Label(self, text='MATH', font=('Candara', 50, 'bold'), fg='black', bg='white')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=300)
        big_lable = tk.Label(self, text='ENGLISH', font=('Candara', 50, 'bold'), fg='black', bg='white')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=100)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Candara', 15, 'bold'), bg='white', fg='black')
        login_entry.pack(pady=30)
        login_entry.place(x=500, y=150)


        def get_chouce():
            controller.show_frame('get_Lesson')

        contact_button = tk.Button(self, text="chouce", command=(get_chouce), font=('Candara', 15, 'bold'),fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=700, y=200)



        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='white', bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)

class Teachers(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')


        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="о студентов", command=(get_aboutstudents), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=200)


        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для жалоб", command=(get_aboutstudents), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=300)

        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для выкладывания записанных уроков  ", command=(get_aboutstudents),
                                   font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=400)




        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='black', bg='white')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)

class Schedules(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='Schedules Lessons', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)



        text = tk.Label(self, text='IN MONDAY LESSON FOR IN 13:00-16:00 \n', font=('Candara', 15, 'bold'), fg='white', bg='red')
        text.pack(pady=10)


        text = tk.Label(self, text='IN TUESDAY YOU  ARE FREE \n', font=('Candara', 15, 'bold'), fg='white', bg='red')
        text.pack(pady=10)

        text = tk.Label(self, text='IN WEDNESADY LESSON FOR IN 10:00-12:00 \n', font=('Candara', 15, 'bold'), fg='white',
                        bg='red')
        text.pack(pady=10)

        text = tk.Label(self, text='IN THURSDAY YOU ARE FREE \n', font=('Candara', 15, 'bold'),
                        fg='white',
                        bg='red')
        text.pack(pady=10)

        text = tk.Label(self, text='IN FRIDAY LESSON FOR IN 10:00-12:00 \n', font=('Candara', 15, 'bold'),
                        fg='white',
                        bg='red')
        text.pack(pady=10)

        text = tk.Label(self, text='IN SATURDAY YOU ARE FRE \n', font=('Candara', 15, 'bold'),
                        fg='white',
                        bg='red')
        text.pack(pady=10)

        text = tk.Label(self, text='IN SUNDAY WILL BE GAME BETWEN SOME GROUPS  \n', font=('Candara', 15, 'bold'),
                        fg='white',
                        bg='red')
        text.pack(pady=10)




        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='white', bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)






class Students(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для просмотров результатов ", command=(get_aboutstudents), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=300)

        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для просмотра записанных уроков ", command=(get_aboutstudents), font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=400)

        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для жалоб ", command=(get_aboutstudents),
                                   font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=500)






        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='white', bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)




class Payments(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='Online payment', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Candara', 15, 'bold'), bg='white', fg='black')
        login_entry.pack(pady=30)

        def get_Send():
            controller.show_frame('PIPI')

        contact_button = tk.Button(self, text="send", command=(get_Send), font=('Candara', 20, 'bold'), fg='white', bg='red')
        contact_button.pack(pady=30)
        contact_button.place(x=800, y=250)

        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для просмотра биологического потомка", command=(get_aboutstudents),
                                   font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=300)



        def get_aboutstudents():
            controller.show_frame(' о студентов ')

        contact_button = tk.Button(self, text="кабинет для жалобы",
                                   command=(get_aboutstudents),
                                   font=('Candara', 20, 'bold'), fg='black', bg='white')
        contact_button.pack(pady=30)
        contact_button.place(x=10, y=400)




        def return_MenuPage():
            controller.show_frame('MenuPage')

        return_button = tk.Button(self, text='Back', command=return_MenuPage,font=('Candara', 10, 'bold'), fg='white', bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)






class get_Lesson(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='Choice courses ', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=500, y=10)
        big_lable = tk.Label(self, text='Nigina.Pre-inter', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=100)
        big_lable = tk.Label(self, text='Aziza.Inter', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=200)
        big_lable = tk.Label(self, text='Asadbek.Pre-IELTS', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=300)

        my_login = tk.StringVar()
        login_entry = tk.Entry(self, textvariable=my_login, font=('Candara', 15, 'bold'), bg='white', fg='black')
        login_entry.pack(pady=30)
        login_entry.place(x=500, y=130)

        def get_next():
            controller.show_frame('get_Pricelist')

        contact_button = tk.Button(self, text="send", command=(get_next), font=('Candara', 20, 'bold'), fg='white',
                                   bg='red')
        contact_button.pack(pady=30)
        contact_button.place(x=800, y=250)



        def return_Courses():
            controller.show_frame('Courses')

        return_button = tk.Button(self, text='Back', command=return_Courses, font=('Candara', 10, 'bold'), fg='white',
                                  bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)





class get_Pricelist(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="red")
        self.controller = controller
        self.controller.title('I KNOW ACADEMY')
        self.controller.state('zoomed')

        big_lable = tk.Label(self, text='Choice LESSONS ', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=500, y=10)
        big_lable = tk.Label(self, text='Nigina.LESSONS (1,2,3,4,5,6,7,8,9', font=('Candara', 50, 'bold'), fg='white', bg='red')
        big_lable.pack(pady=30)
        big_lable.place(x=10, y=100)

        courcec_1 = tk.Label(self, text="выберите урок ", font=('Monotype', 15, 'bold'), fg="red", bg="white")
        courcec_1.pack()
        courcec_1.place(x=570, y=250, )
        natija = tk.Label(self, text='оплата')
        natija.place(x=620, y=310, )
        a = 5500
        miqdor = tk.Entry(self)
        miqdor.pack()
        miqdor.place(x=480, y=310, )

        def farq():
            narx = a
            natija.config(text=int(narx) * int(miqdor.get()))

        tugma = tk.Button(self, text='расчитать', command=farq)
        tugma.place(x=380, y=310)

        def return_Courses():
                   controller.show_frame('get_Lesson')

        return_button = tk.Button(self, text='Back', command=return_Courses, font=('Candara', 10, 'bold'), fg='white',
                              bg='black')
        return_button.pack(pady=300)
        return_button.place(x=10, y=10)



if __name__=='__main__':
    app = SampleApp()
    app.mainloop()

